-- Require the configuration from the mod info and adapt it.
LANGUAGE = GetModConfigData("LANGUAGE")
cooldown_number = GetModConfigData("cooldown_number")

FABRICATIONANNOUNCER = GetModConfigData("FABRICATIONANNOUNCER")
HAMMERINGANNOUNCER = GetModConfigData("HAMMERINGANNOUNCER")
LIGHTINGANNOUNCER = GetModConfigData("LIGHTINGANNOUNCER")
ATTACKANNOUNCER = GetModConfigData("ATTACKANNOUNCER")
DEATHANNOUNCER = GetModConfigData("DEATHANNOUNCER")
SOUNDPLAYER = GetModConfigData("SOUNDPLAYER")

cooldown_status = false

local prefabs_to_check = {
	arrowsign_post       = true,
	beebox               = true,
	beehive              = true,
	berrybush            = true,
	berrybush2           = true,
	berrybush_juicy      = true,
	birdcage             = true,
	cartographydesk      = true,
	catcoonden           = true,
	cave_banana_tree     = true,
	coldfirepit          = true,
	cookpot              = true,
	dragonflychest       = true,
	dragonflyfurnace     = true,
	saladfurnace         = true,
	endtable             = true,
	slow_farmplot        = true,
	fast_farmplot        = true,
	fence                = true,
	fence_gate           = true,
	firepit              = true,
	firesuppressor       = true,
	grass                = true,
	homesign             = true,
	hound_mound          = true,
	icebox               = true,
	lightningrod         = true,
	livingtree           = true,
	meatrack             = true,
	mermhouse            = true,
	minisign             = true,
	monkeybarrel         = true,
	moondial             = true,
	mushroom_farm        = true,
	mushroom_light       = true,
	mushroom_light2      = true,
	nightlight           = true,
	perdshrine           = true,
	pighouse             = true,
	pigtorch             = true,
	pottedfern           = true,
	rabbithouse          = true,
	rainometer           = true,
	resurrectionstatue   = true,
	ruinsrelic_plate     = true,
	ruinsrelic_bowl      = true,
	ruinsrelic_chair     = true,
	ruinsrelic_chipbowl  = true,
	ruinsrelic_vase      = true,
	ruinsrelic_table     = true,
	saltlick             = true,
	scarecrow            = true,
	researchlab          = true,
	researchlab2         = true,
	researchlab3         = true,
	researchlab4         = true,
	sapling              = true,
	sculptingtable       = true,
	sentryward           = true,
	succulent_potted     = true,
	telebase             = true,
	tent                 = true,
	siestahut            = true,
	townportal           = true,
	treasurechest        = true,
	wall_hay             = true,
	wall_wood            = true,
	wall_stone           = true,
	wall_ruins           = true,
	wall_moonrock        = true,
	wardrobe             = true,
	winterometer         = true,
	winter_tree          = true,
	winter_twiggytree    = true,
	winter_deciduoustree = true,
	winter_treestand     = true,
}

-- Configure languages.

if LANGUAGE == "english" then

	a_quantity = "A "
	has_been_made_by = " has been made by "
	has_been_hammered_by = " has been hammered by "
	has_been_lit_by = " has been ignited by "
	has_been_attacked = " has been attacked by "
	has_been_killed = " has been killed!!"
	print("(CA) English language loaded!")	

-- Grammatical order: Same as english.
elseif LANGUAGE == "spanish" then

	a_quantity = "¡Ún "
	has_been_made_by = " ha sido hecho por "
	has_been_hammered_by = " ha sido martillado por "
	has_been_lit_by = " ha sido encendido por "
	has_been_attacked = " ha sido atacado por "
	has_been_killed = " ha sido asesinado!!"
	print("(CA) Spanish language loaded! - ¡Lenguaje español cargado!")	

-- Grammatical order: Player Name + Sentence + Item Name.
elseif LANGUAGE == "simplified_chinese" then

	has_been_made_by = " 制作了 "
	has_been_hammered_by = " 摧毁了 "
	has_been_lit_by = " 点燃了 "
	has_been_attacked = " 攻击了 "
	has_been_killed = " 被杀死了 "
	print("(CA) Simplified Chinese language loaded!")

-- Grammatical order: Item Name + Player Name + Sentence.
elseif LANGUAGE == "turkish" then

	a_quantity = "ı "
	has_been_made_by = " tarafından yapıldı "
	has_been_hammered_by = " tarafından imha edildi "
	has_been_lit_by = " tarafından yakıldı "
	has_been_attacked = " a saldırdı "
	has_been_killed = " öldürüldü!! "
	print("(CA) Turkish language loaded!")

-- Grammatical order: Same as english.
elseif LANGUAGE == "greek" then

	a_quantity = "Ένα "
	has_been_made_by = " φτιάχτηκε απο το "
	has_been_lit_by = " ανάφτηκε σε φλόγες απο το "
	has_been_attacked =  " δέχτηκε επίθεση από το "
	has_been_hammered_by = "σφυροκοπήθηκε από "  
	has_been_killed = " Το σκοτώθηκε!! "
	print("(CA) Greek language loaded!")

-- Grammatical order: Same as english.
elseif LANGUAGE == "italian" then

	a_quantity = "Un "
	has_been_made_by = " è stato fatto da "
	has_been_hammered_by = " è stato martellato da "
	has_been_lit_by = " è stato acceso da "
	has_been_attacked = " è stato attaccato da "
	has_been_killed = " è stato ucciso!! "
	print("(CA) Italian language loaded!")

-- Grammatical order: Same as english.
elseif LANGUAGE == "romanian" then

	a_quantity = "O "
	has_been_made_by = " a fost creat de "
	has_been_hammered_by = " a fost lovit de "
	has_been_lit_by = " a fost ars de "
	has_been_attacked = " a fost atacat de "
	has_been_killed = " a ucis de "
	print("(CA) Romanian language loaded!")

--[[ Grammatical order: Same as english.
EXCEPTION: LIGHTING: PLAYER NAME + SENTENCE + ITEM NAME.
--]]

elseif LANGUAGE == "portuguese" then
	a_quantity = "Uma "
	has_been_made_by = " foi  criada por "
	has_been_hammered_by = " foi marretado por "
	has_been_lit_by = " foi acendeu por "
	has_been_attacked = " foi atacado por "
	has_been_killed = " não vive mais "
	print ("(CA) Brazilian Portuguese language loaded! - Idioma Português Brasileiro foi carregado!")

end

-- GRAMMATICAL ORDERS

--- FABRICATION BEGIN

function GrammaticalFabricationOrder1(inst, prod) -- Chinese.
	
		if FABRICATIONANNOUNCER then
			GLOBAL.TheNet:Announce(inst:GetDisplayName()..has_been_made_by..prod:GetDisplayName().."!")
		end

end

function GrammaticalFabricationOrder2(inst, prod) -- English, spanish, romanian, greek, italian, portuguese.
	
		if FABRICATIONANNOUNCER then
			GLOBAL.TheNet:Announce(a_quantity..prod:GetDisplayName()..has_been_made_by..inst:GetDisplayName().."!")
		end

end

function GrammaticalFabricationOrder3(inst, prod) -- Turkish.
	
		if FABRICATIONANNOUNCER then
			GLOBAL.TheNet:Announce(prod:GetDisplayName()..inst:GetDisplayName()..has_been_made_by.."!")
		end

end

-- FABRICATION END

-- HAMMERING BEGIN

function GrammaticalHammeringOrder1(act) -- Chinese.

	GLOBAL.TheNet:Announce(act.doer:GetDisplayName()..has_been_hammered_by..act.target:GetDisplayName().."!")

end

function GrammaticalHammeringOrder2(act) -- English, spanish, romanian, greek, italian, portuguese.
	
	GLOBAL.TheNet:Announce(a_quantity..act.target:GetDisplayName()..has_been_hammered_by..act.doer:GetDisplayName().."!")


end

function GrammaticalHammeringOrder3(act) -- Turkish.
	
	GLOBAL.TheNet:Announce(act.target:GetDisplayName()..act.doer:GetDisplayName()..has_been_hammered_by.."!")

end

-- HAMMERING END

--- LIGHTING BEGIN

function GrammaticalLightingOrder1(act) -- Chinese, portuguese.
	
		if LIGHTINGANNOUNCER then
			GLOBAL.TheNet:Announce(act.doer:GetDisplayName()..has_been_lit_by..act.target:GetDisplayName().."!!")
		end

end

function GrammaticalLightingOrder2(act) -- English, spanish, romanian, greek, italian.
	
		if LIGHTINGANNOUNCER then
			GLOBAL.TheNet:Announce(a_quantity..act.target:GetDisplayName()..has_been_lit_by..act.doer:GetDisplayName().."!!")
		end

end

function GrammaticalLightingOrder3(act) -- Turkish.
	
		if LIGHTINGANNOUNCER then
			GLOBAL.TheNet:Announce(act.target:GetDisplayName()..act.doer:GetDisplayName()..has_been_lit_by.."!!")
		end

end

-- LIGHTING END

-- FOLLOWER ATTACK BEGIN

function GrammaticalAttackOrder1(inst, data) -- Chinese.
	
		if ATTACKANNOUNCER then
			GLOBAL.TheNet:Announce(data.attacker:GetDisplayName()..has_been_attacked..inst:GetDisplayName().."!!")
		end

end

function GrammaticalAttackOrder2(inst, data) -- English, spanish, romanian, greek, italian, portuguese.
	
		if ATTACKANNOUNCER then
			GLOBAL.TheNet:Announce(a_quantity..inst:GetDisplayName()..has_been_attacked..data.attacker:GetDisplayName().."!!")
		end

end

function GrammaticalAttackOrder3(inst, data) -- Turkish.
	
		if ATTACKANNOUNCER then
			GLOBAL.TheNet:Announce(inst:GetDisplayName()..data.attacker:GetDisplayName()..has_been_attacked.."!!")
		end

end

-- FOLLOWER ATTACK END

-- IMPORTANT DEATH BEGIN

function GrammaticalDeathOrder1(inst, data) -- Chinese.
	
		if DEATHANNOUNCER then
			GLOBAL.TheNet:Announce(inst:GetDisplayName()..has_been_killed.."!! ("..inst.lastAttacker_name..")")
		end
			if SOUNDPLAYER then
				TheFrontEnd:GetSound():PlaySound("dontstarve/HUD/Together_HUD/player_receives_gift_animation_spin")
			end

end

function GrammaticalDeathOrder2(inst, data) -- English, spanish, romanian, greek, italian, portuguese.
	
		if DEATHANNOUNCER then
			GLOBAL.TheNet:Announce(a_quantity..inst:GetDisplayName()..has_been_killed.."("..inst.lastAttacker_name..")")
		end
			if SOUNDPLAYER then
				TheFrontEnd:GetSound():PlaySound("dontstarve/HUD/Together_HUD/player_receives_gift_animation_spin")
			end

end

function GrammaticalDeathOrder3(inst, data) -- Turkish.
	
		if DEATHANNOUNCER then
			GLOBAL.TheNet:Announce(inst:GetDisplayName()..has_been_killed.."("..inst.lastAttacker_name..")")
		end
		if SOUNDPLAYER then
			TheFrontEnd:GetSound():PlaySound("dontstarve/HUD/Together_HUD/player_receives_gift_animation_spin")
		end			

end

-- IMPORTANT DEATH END

function cooldown_end()

cooldown_status = false

end

-- ANNOUNCE AND VALIDATE FABRICATION

	local function OnBuild_becomevalid(inst, prod)

	    if prefabs_to_check[prod.prefab] then

	        prod:AddTag("valid_ca_prod")
	 
			if LANGUAGE == "simplified_chinese" and cooldown_status == false then
				GrammaticalFabricationOrder1(inst, prod)
				print("(CA) "..inst:GetDisplayName()..has_been_made_by..prod:GetDisplayName().."!")
				if GLOBAL.TheNet:GetIsServer() then 
					GLOBAL.TheWorld:DoPeriodicTask(cooldown_number, cooldown_end)
				end

			elseif LANGUAGE == "spanish" or "english" or "romanian" or "greek" or "italian" or "portuguese" and cooldown_status == false then
				GrammaticalFabricationOrder2(inst, prod)
				print("(CA) "..a_quantity..prod:GetDisplayName()..has_been_made_by..inst:GetDisplayName().."!")
				if GLOBAL.TheNet:GetIsServer() then 
					GLOBAL.TheWorld:DoPeriodicTask(cooldown_number, cooldown_end)
				end

			elseif LANGUAGE == "turkish" and cooldown_status == false then
				GrammaticalFabricationOrder3(inst, prod)
				print("(CA) "..prod:GetDisplayName()..inst:GetDisplayName()..has_been_made_by.."!")
				if GLOBAL.TheNet:GetIsServer() then 
					GLOBAL.TheWorld:DoPeriodicTask(cooldown_number, cooldown_end)
				end

			end

			cooldown_status = true

		end

		if inst.components.builder.bn_Old_onBuild_Fn then
			inst.components.builder.bn_Old_onBuild_Fn(inst, prod)
		end

	end

AddPlayerPostInit(function(inst)
	if inst.components.builder then
		if inst.components.builder.onBuild then
			inst.components.builder.bn_Old_onBuild_Fn = inst.components.builder.onBuild
		end
		inst.components.builder.onBuild = OnBuild_becomevalid
	end
end)

-- ANNOUNCE HAMMERING

local old_ACTION_HAMMER = GLOBAL.ACTIONS.HAMMER.fn
GLOBAL.ACTIONS.HAMMER.fn = function(act, inst)
	if act.target:HasTag("valid_ca_prod") then

		if LANGUAGE == "simplified_chinese" and cooldown_status == false then
			GrammaticalHammeringOrder1(act)
			print("(CA) "..act.doer:GetDisplayName()..has_been_hammered_by..act.target:GetDisplayName().."!")
			if GLOBAL.TheNet:GetIsServer() then 
				GLOBAL.TheWorld:DoPeriodicTask(cooldown_number, cooldown_end)
			end

		elseif LANGUAGE == "spanish" or "english" or "romanian" or "greek" or "italian" or "portuguese" and cooldown_status == false then
			GrammaticalHammeringOrder2(act)
			print("(CA) "..a_quantity..act.target:GetDisplayName()..has_been_hammered_by..act.doer:GetDisplayName().."!")
			if GLOBAL.TheNet:GetIsServer() then 
				GLOBAL.TheWorld:DoPeriodicTask(cooldown_number, cooldown_end)
			end

		elseif LANGUAGE == "turkish" and cooldown_status == false then
			GrammaticalHammeringOrder3(act)
			print("(CA) "..act.target:GetDisplayName()..act.doer:GetDisplayName()..has_been_hammered_by.."!")
			if GLOBAL.TheNet:GetIsServer() then 
				GLOBAL.TheWorld:DoPeriodicTask(cooldown_number, cooldown_end)
			end

		end

			cooldown_status = true

	end

return old_ACTION_HAMMER(act)

end

-- ANNOUNCE LIGHTING

local old_LIGHT_function = GLOBAL.ACTIONS.LIGHT.fn
GLOBAL.ACTIONS.LIGHT.fn = function(act, inst)
	if act.target:HasTag("valid_ca_prod") then

		if LANGUAGE == "simplified_chinese" and cooldown_status == false then
			GrammaticalLightingOrder1(act)
			print("(CA) "..act.doer:GetDisplayName()..has_been_hammered_by..act.target:GetDisplayName().."!")
			if GLOBAL.TheNet:GetIsServer() then 
				GLOBAL.TheWorld:DoPeriodicTask(cooldown_number, cooldown_end)
			end

		elseif LANGUAGE == "spanish" or "english" or "romanian" or "greek" or "italian" or "portuguese" and cooldown_status == false then
			GrammaticalLightingOrder2(act)
			print("(CA) "..a_quantity..act.target:GetDisplayName()..has_been_hammered_by..act.doer:GetDisplayName().."!")
			if GLOBAL.TheNet:GetIsServer() then 
				GLOBAL.TheWorld:DoPeriodicTask(cooldown_number, cooldown_end)
			end

		elseif LANGUAGE == "turkish" and cooldown_status == false then
			GrammaticalLightingOrder3(act)
			print("(CA) "..act.target:GetDisplayName()..act.doer:GetDisplayName()..has_been_hammered_by.."!")
			if GLOBAL.TheNet:GetIsServer() then 
				GLOBAL.TheWorld:DoPeriodicTask(cooldown_number, cooldown_end)
			end

		end

			cooldown_status = true

	end

return old_LIGHT_function(act)

end

-- VALID ATTACKS
followernames ={
    
	"chester",
	"hutch",
	"glommer",
	"wall_hay",
	"wall_wood",
	"wall_stone",
	"wall_ruins",
	"wall_moonrock",	

}

function followers(inst)

  	function followerattacked(inst, data)


		if LANGUAGE == "simplified_chinese" and cooldown_status == false then
			GrammaticalAttackOrder1(inst, data)
			print("(CA) "..data.attacker:GetDisplayName()..has_been_attacked..inst:GetDisplayName().."!!")
			if GLOBAL.TheNet:GetIsServer() then 
				GLOBAL.TheWorld:DoPeriodicTask(cooldown_number, cooldown_end)
			end

		elseif LANGUAGE == "spanish" or "english" or "romanian" or "greek" or "italian" or "portuguese" and cooldown_status == false then
			GrammaticalAttackOrder2(inst, data)
			print("(CA) "..a_quantity..inst:GetDisplayName()..has_been_attacked..data.attacker:GetDisplayName().."!!")
			if GLOBAL.TheNet:GetIsServer() then 
				GLOBAL.TheWorld:DoPeriodicTask(cooldown_number, cooldown_end)
			end

		elseif LANGUAGE == "turkish" and cooldown_status == false then
			GrammaticalAttackOrder3(inst, data)
			print("(CA) "..inst:GetDisplayName()..data.attacker:GetDisplayName()..has_been_attacked.."!!")
			if GLOBAL.TheNet:GetIsServer() then 
				GLOBAL.TheWorld:DoPeriodicTask(cooldown_number, cooldown_end)
			end

		end

			cooldown_status = true

    end

    inst:ListenForEvent("attacked", followerattacked)

end

for k, v in pairs(followernames) do
	AddPrefabPostInit(v, followers)
end

-- VALID DEATHS
boss ={
    
	"bearger",
	"deerclops",
	"moose",
	"dragonfly",
	"minotaur",
	"klaus",
	"antlion",
	"beequeen",
	"toadstool",
	"stalker_atrium",
	"walrus",
	"chester",
	"hutch",
	"glommer",
	"toadstool_dark",

}

function bosscheck(inst, data)

	inst:ListenForEvent("attacked", bossattacked)
	inst:ListenForEvent("death", bosskilled)

end

function bossattacked(inst, data)

	inst.lastAttacker_name = data.attacker:GetDisplayName()

end

function bosskilled(inst, data)
	
	inst.lastAttacker_name = data.afflicter and data.afflicter:GetDisplayName() or inst.lastAttacker_name or "?"
    local lastAttacker_name = inst.lastAttacker_name or "?"
    
    if LANGUAGE == "simplified_chinese" then
        GrammaticalDeathOrder1(inst, data)
        print("(CA) "..inst:GetDisplayName()..has_been_killed.."!! ("..lastAttacker_name..")")
    
    elseif LANGUAGE == "spanish" or "english" or "romanian" or "greek" or "italian" or "portuguese" then
        GrammaticalDeathOrder2(inst, data)
        print("(CA) "..a_quantity..inst:GetDisplayName()..has_been_killed.."("..lastAttacker_name..")")
    
    elseif LANGUAGE == "turkish" then
        GrammaticalDeathOrder3(inst, data)
        print("(CA) "..inst:GetDisplayName()..has_been_killed.."("..lastAttacker_name..")")
    end

end


for k, v in pairs(boss) do
	AddPrefabPostInit(v, bosscheck)
end


-- Code courtesy of https://forums.kleientertainment.com/profile/552758-carlzalph/ and modified in UP7HO4 , thanks!!
local function HookThis(prefab)
    AddPrefabPostInit(
        prefab,
        function(inst)
            if not GLOBAL.TheWorld.ismastersim
            then
                return
            end
            inst:AddTag("valid_ca_prod")
        end
    )
end

for prefab,_ in pairs(prefabs_to_check) do
    HookThis(prefab)
end