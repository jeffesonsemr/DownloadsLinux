name = "Cooperative Announcer"

version = "UP7HO6"

description = "Version:"..version..", February 3, 2018. Check Workshop Page for Special Thanks. \n\n Annnounces fabricating, burning and breaking things, deaths of bosses and attacks & deaths of followers. \n\n The mod creator needs your help! Consider donating to him, links The Steam Workshop Page... Thanks for using this mod and helping!\n\n Translators (Also available in Steam Workshop Page): \n\n English, Español: Residays. \n 简体中文: 逐竹影 ( http://steamcommunity.com/profiles/76561198230633620 ), GoForDream ( http://steamcommunity.com/profiles/76561198311311669 ) \nPortuguês (Brasileiro): Augusto/Augusonic, http://steamcommunity.com/profiles/76561198071015027/ \n Türkçe (Türkiye): Nacho, http://steamcommunity.com/profiles/76561198287935783 \n Italiano: Andaya, http://steamcommunity.com/profiles/76561198104907475 \n Ελληνικά.: Kek/Charcoal, http://steamcommunity.com/profiles/76561198440516291/ \n Română: Wishes to stay hidden."

author = "Residays"

forumthread = "http://forums.kleientertainment.com/topic/77983-release-announce-important-cooperative-actions/"

api_version = 10

icon_atlas = "atlas.xml"
icon = "icon.tex"

dst_compatible = true

client_only_mod = false
all_clients_require_mod = false

server_filter_tags = {"Announce Important Cooperative Actions", "Cooperative Announcer"}

configuration_options ={
{
		name = "LANGUAGE",
		label = "Language",
		options = {
						{description = "English (IN).", hover = "International English.", data = "english"},
						{description = "Español (LA).", hover = "Español Latinoaméricano (South-American Spanish).", data = "spanish"},
						{description = "简体中文。", hover = "中国 (Simplified Chinese)。", data = "simplified_chinese"},
						{description = "Türkçe (Türkiye).", hover = "Turkish (Turkey).", data = "turkish"},
						{description = "Ελληνικά.", hover = "Greek (EXPERIMENTAL!).", data = "greek"},
						{description = "Italiano.", hover = "Italian.", data = "italian"},
						{description = "Română.", hover = "Romanian (Romania).", data = "romanian"},
						{description = "Português (Brasileiro).", hover = "Romanian (Romania).", data = "portuguese"},
					},
		default = "english",
		hover = "The language that the announcements will be displayed in.",
	},
	{
		name = "SOUNDPLAYER",
		label = "Death Sound",
		options = {
						{description = "Play.", data = true},
						{description = "None.", data = false},
					},
		default = false,
		hover = "Should Death announcements also play a sound?",
	},		
	{
		name = "FABRICATIONANNOUNCER",
		label = "Make Important",
		options = {
						{description = "Announce.", data = true},
						{description = "Silent.", data = false},
					},
		default = true,
		hover = "Should fabrications be announced in the server?",
	},
	{
		name = "HAMMERINGANNOUNCER",
		label = "Hammering Important",
		options = {
						{description = "Announce.", data = true},
						{description = "Silent.", data = false},
					},
		default = true,
		hover = "Should hammering be announced in the server?",
	},
	{
		name = "LIGHTINGANNOUNCER",
		label = "Lighting Important",
		options = {
						{description = "Announce.", data = true},
						{description = "Silent.", data = false},
					},
		default = true,
		hover = "Should lighting be announced in the server?",
	},
	{
		name = "ATTACKANNOUNCER",
		label = "Attack Followers",
		options = {
						{description = "Announce.", data = true},
						{description = "Silent.", data = false},
					},
		default = false,
		hover = "Should the attack of followers be announced?",
	},
	{
		name = "DEATHANNOUNCER",
		label = "Important Death",
		options = {
						{description = "Announce.", data = true},
						{description = "Silent.", data = false},
					},
		default = true,
		hover = "Should the death of Important Mobs (MacTusk, Bosses and Followers) be announced? This overrides cooldowns.",
	},
	{
		name = "cooldown_number",
		label = "Cooldown Duration",
		options = {
						{description = "None (Spammy).", data = 0},
						{description = "3 seconds", data = 3},
						{description = "5 seconds.", data = 5},
						{description = "8 seconds.", data = 8},
						{description = "15 seconds.", data = 15},
					},
		default = 5,
		hover = "EXPERIMENTAL: How long should we wait to allow another announcement? (Not for deaths)",	
	},
}